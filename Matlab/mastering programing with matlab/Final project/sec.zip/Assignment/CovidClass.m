classdef CovidClass < handle
    properties
        ParentRegion=[];
        ChildRegion={};
        Region;
        Cases;
        Deaths;
    end
    
    methods
        function obj = CovidClass(region, cases, deaths)
            obj.Region = string(region);
            obj.Cases = cases;
            obj.Deaths = deaths;
        end
        
        function addChildReg(obj, newObj)
            obj.ChildRegion{end+1} = newObj;
            newObj.ParentRegion = obj;
        end 
       
    end
end